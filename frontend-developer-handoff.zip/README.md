# Frontend Developer Handoff — Kindergarten Management System

Everything needed to build the web frontend against the existing NestJS backend API.
**This package is self-contained** — you do not need access to the backend source code.

## What's in here

| File | What it is |
|---|---|
| `openapi.json` | The machine-readable API schema — **authority on exact request/response field names**. Generate your typed client from this. |
| `docs/frontend-integration-guide.md` | **Start here.** The cross-cutting wire contract: auth + refresh flow, error envelope + full error-code registry, money-as-tiyin, dates, pagination, idempotency, RBAC mechanics, recommended stack, project structure. |
| `docs/frontend-functional-spec.md` | The module-by-module reference: all 22 modules with endpoints, response structure, business rules, screen requirements, and which roles use each. Start here when building any feature. |
| `.claude/agents/frontend-developer.md` | A Claude Code subagent definition. Drop it into your frontend repo's `.claude/agents/` to get an agent that knows this contract cold. |
| `kindergarten-docs/docs/03-billing-rules.md` | Optional deep-dive: billing/proration rules (for building the billing + tariff UI). |
| `kindergarten-docs/docs/05-telegram-spec.md` | Optional deep-dive: Telegram integration behavior. |

## Recommended stack

React 18 + TypeScript + Vite · TanStack Query · types generated from `openapi.json`
(`openapi-typescript`) · React Router · React Hook Form + Zod · shadcn/ui **or** MUI ·
react-i18next (`ru` default, `uz`).

## Getting started

1. Read `docs/frontend-integration-guide.md` end to end — the rules there are non-negotiable
   (money is integer-tiyin strings, localize from error `code`, httpOnly refresh cookie, etc.).
2. Scaffold the app (e.g. `npm create vite@latest` with the React + TS template).
3. Copy `openapi.json` into the project (e.g. `src/api/openapi.json`) and generate types:
   ```bash
   npx openapi-typescript ./src/api/openapi.json -o src/api/schema.d.ts
   ```
   Add an npm script `"gen:api": "openapi-typescript ./src/api/openapi.json -o src/api/schema.d.ts"`
   and re-run it whenever you get a refreshed `openapi.json`.
4. Build the API client + refresh loop, error-code→i18n map, money/date helpers, and the
   permission hook **once** (Integration Guide §10), then build features against them.
5. Point the client at the API base URL `http://localhost:3010/api/v1`, and make sure your dev
   origin is in the backend's `CORS_ORIGINS`.

## Notes

- **`openapi.json` is the source of truth for field names.** Where the docs spell out a shape,
  it's structural guidance — if it ever disagrees with the schema, the schema wins.
- The backend serves the same schema live at `http://localhost:3010/docs` (Swagger UI) when running.
- All internal links between these docs are relative and resolve within this folder as-is.
